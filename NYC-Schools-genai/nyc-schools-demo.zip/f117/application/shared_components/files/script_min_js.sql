prompt --application/shared_components/files/script_min_js
begin
--   Manifest
--     APP STATIC FILES: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '66756E6374696F6E207479706545666665637428742C65297B636F6E7374206E3D646F63756D656E742E676574456C656D656E74427949642874293B6C6574206C3D652E7472696D28292E73706C697428225C6E22292C633D302C6F3D303B2166756E63';
wwv_flow_imp.g_varchar2_table(2) := '74696F6E207428297B696628633C6C2E6C656E677468297B636F6E737420653D6C5B635D3B6F3C652E6C656E6774683F286E2E76616C75652B3D652E636861724174286F292C6F2B2B2C73657454696D656F757428742C313029293A286E2E76616C7565';
wwv_flow_imp.g_varchar2_table(3) := '2B3D225C6E222C632B2B2C6F3D302C742829292C6E2E7363726F6C6C546F703D6E2E7363726F6C6C4865696768747D7D28297D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(186310704863617085)
,p_file_name=>'script.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
