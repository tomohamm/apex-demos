prompt --application/shared_components/workflow/task_definitions/apply_to_school
begin
--   Manifest
--     TASK_DEF: Apply To School
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(324471764663354801)
,p_name=>'Apply To School'
,p_static_id=>'APPLY_TO_SCHOOL'
,p_subject=>'School Application'
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,8:P8_TASK_ID:&TASK_ID.'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(10025671261299399)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_name=>'Update Task ID on create'
,p_execution_sequence=>40
,p_on_event=>'CREATE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'UPDATE NYC_SCHOOLS_APPS SET TASK_ID = :APEX$TASK_ID WHERE ID = :APEX$TASK_PK;'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(324796737534277266)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_name=>'Approved Application'
,p_execution_sequence=>10
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l_p_name varchar(255); l_s_name varchar(255);',
'begin',
'    update nyc_schools_apps set disposition=''APPROVED'', updated=sysdate, updated_by=:APP_USER ',
'        where id=:APEX$TASK_PK returning parent_user, student_name into l_p_name, l_s_name;',
'',
'       apex_pwa.send_push_notification (',
'        p_user_name  => upper(l_p_name),',
'        p_title      => ''School Application for '' || l_s_name || '' has been APPROVED!'',',
'        p_body       => ''School Application for '' || l_s_name || '' has been APPROVED!'',',
'        p_target_url => apex_util.host_url || apex_util.prepare_url ( p_url => ''f?p=''|| :APP_ID || '':1:'', p_plain_url => true ) );',
'',
'        apex_pwa.push_queue;',
'end;',
''))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(325776559130937370)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_name=>'Rejected Application'
,p_execution_sequence=>20
,p_outcome=>'REJECTED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l_p_name varchar(255); l_s_name varchar(255);',
'begin',
'    update nyc_schools_apps set disposition=''REJECTED'', updated=sysdate, updated_by=:APP_USER ',
'        where id=:APEX$TASK_PK returning parent_name, student_name into l_p_name, l_s_name;',
'',
'       apex_pwa.send_push_notification (',
'        p_user_name  => upper(l_p_name),',
'        p_title      => ''School Application for '' || l_s_name || '' has been REJECTED!'',',
'        p_body       => ''School Application for '' || l_s_name || '' has been REJECTED!'',',
'        p_target_url => apex_util.host_url || apex_util.prepare_url ( p_url => ''f?p=''|| :APP_ID || '':1:'', p_plain_url => true ) );',
'',
'        apex_pwa.push_queue;',
'end;',
''))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_success_message=>'This School Application has been Rejected!'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(326478907695913759)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_name=>'Comment push notification to PARENT'
,p_execution_sequence=>30
,p_on_event=>'UPDATE_COMMENT'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l_p_user varchar(255); l_s_name varchar(255); l_app_id number;',
'begin',
'   ',
'    select id, parent_user, student_name into l_app_id, l_p_user, l_s_name from  nyc_schools_apps ',
'        where id=:APEX$TASK_PK ;',
'        ',
'        apex_debug.info(''new comment : %s %s'', l_app_id, :APEX$TASK_PK);',
'    if l_p_user<>:APP_USER then',
'       apex_pwa.send_push_notification (',
'        p_user_name  => l_p_user, ',
'        p_title      => ''School Application for '' || l_s_name || '' has a new comment!'',',
'        p_body       => ''School Application for '' || l_s_name || '' has a new comment!'',',
'        p_target_url => apex_util.host_url || apex_util.prepare_url ( p_url => ''f?p=''|| :APP_ID || '':1:'', p_plain_url => true ) );',
'',
'        apex_pwa.push_queue;',
'    end if;',
'end;',
''))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(324472075486354805)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'NYC.ADMIN'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(324472453342354808)
,p_task_def_id=>wwv_flow_imp.id(324471764663354801)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'NYC.ADMIN'
);
wwv_flow_imp.component_end;
end;
/
