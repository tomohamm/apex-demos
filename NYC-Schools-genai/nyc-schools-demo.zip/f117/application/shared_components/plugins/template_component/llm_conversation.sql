prompt --application/shared_components/plugins/template_component/llm_conversation
begin
--   Manifest
--     PLUGIN: LLM_CONVERSATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(50996712494192254048)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'LLM_CONVERSATION'
,p_display_name=>'LLM Conversation'
,p_supported_component_types=>'PARTIAL:REPORT'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','LLM_CONVERSATION'),'')
,p_javascript_file_urls=>'#PLUGIN_FILES#llm-conversations#MIN#.js'
,p_css_file_urls=>'#PLUGIN_FILES#llm-conversations#MIN#.css'
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class = "prompt-box">',
'    <Span>#PROMPT#</Span>',
'</div>',
'',
'<div>',
'<pre id = "response-#ID#" class = "response response-box">#RESPONSE#</pre>',
'<div>#ADDITIONAL_ACTIONS#',
'    ',
'</div>',
'</div>'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>2
,p_report_body_template=>'<div>#APEX$ROWS#</div>'
,p_report_row_template=>'<div class="prompt-container" #APEX$ROW_IDENTIFICATION#>#APEX$PARTIAL#</div>'
,p_report_placeholder_count=>3
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>85
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(50996713478958254061)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'PROMPT'
,p_prompt=>'Prompt'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(310375434155115138)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>40
,p_static_id=>'RESPONSE'
,p_prompt=>'Response'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(51022281540504525127)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'ID'
,p_prompt=>'ID'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(349869427643671489)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_name=>'Additional Action template'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="llm-actions rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon #ICON_CLASSES#" aria-hidden="true"></span>',
'    <span class="rw-Button-text">#LABEL#</span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(349868613923662972)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_name=>'Additional Actions'
,p_static_id=>'ADDITIONAL_ACTIONS'
,p_display_sequence=>10
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(349869427643671489)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(310376975055120304)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_file_name=>'llm-conversations.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E70726F6D70742D636F6E7461696E65727B6D617267696E3A313570787D2E70726F6D70742D626F787B77696474683A313030253B70616464696E673A313070783B626F726465723A31707820736F6C696420236433643364333B6261636B67726F756E';
wwv_flow_imp.g_varchar2_table(2) := '642D636F6C6F723A236433643364333B666F6E742D7765696768743A3730307D2E726573706F6E73652D626F787B77696474683A313030253B70616464696E673A313070783B626F726465723A31707820736F6C69643B6D617267696E2D746F703A3570';
wwv_flow_imp.g_varchar2_table(3) := '787D2E6C6C6D2D616374696F6E737B6D617267696E2D6C6566743A313070787D';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(350259032039456230)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_file_name=>'llm-conversations.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E70726F6D70742D636F6E7461696E65727B0A202020206D617267696E3A313570783B0A7D0A2E70726F6D70742D626F78207B0A20202020202077696474683A20313030253B3B0A20202020202070616464696E673A20313070783B0A20202020202062';
wwv_flow_imp.g_varchar2_table(2) := '6F726465723A2031707820736F6C6964206C69676874677261793B0A2020202020206261636B67726F756E642D636F6C6F723A206C69676874677261793B0A202020202020666F6E742D7765696768743A20626F6C643B0A7D0A2E726573706F6E73652D';
wwv_flow_imp.g_varchar2_table(3) := '626F78207B0A20202020202077696474683A20313030253B3B0A20202020202070616464696E673A20313070783B0A202020202020626F726465723A2031707820736F6C69643B0A2020202020206D617267696E2D746F703A203570783B0A7D0A2E6C6C';
wwv_flow_imp.g_varchar2_table(4) := '6D2D616374696F6E737B0A202020206D617267696E2D6C6566743A20313070783B0A7D';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(50997046146419257863)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_file_name=>'llm-conversations.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2F2024282066756E6374696F6E202829207B0A0A202020200A2F2F2020202428222E726573706F6E736522292E656163682866756E6374696F6E2865297B0A2F2F2020202020207661722075726C203D20242874686973292E64617461282275726C22';
wwv_flow_imp.g_varchar2_table(2) := '293B0A2F2F202020202020766172206964203D20242874686973292E646174612822696422293B0A2F2F202020202020636F6E7374206F7074696F6E73203D207B0A2F2F2020202020202020206D6574686F643A2027474554272C0A2F2F202020202020';
wwv_flow_imp.g_varchar2_table(3) := '202020686561646572733A206E65772048656164657273287B27636F6E74656E742D74797065273A20276170706C69636174696F6E2F6A736F6E277D290A2F2F20202020207D3B0A2F2F202020202066657463682875726C290A2F2F2020202E7468656E';
wwv_flow_imp.g_varchar2_table(4) := '28726573706F6E7365203D3E20726573706F6E73652E6A736F6E2829290A2F2F2020202E7468656E2864617461203D3E207B0A2F2F2020202020636F6E736F6C652E6C6F6728646174612E726573706F6E7365293B0A2F2F20202020646F63756D656E74';
wwv_flow_imp.g_varchar2_table(5) := '2E676574456C656D656E74427949642827726573706F6E73652D272B646174612E6964292E696E6E657248544D4C203D20646174612E726573706F6E73653B0A2F2F2020207D290A20202020200A2F2F2020207D290A0A2F2F2020207661722063617264';
wwv_flow_imp.g_varchar2_table(6) := '416374696F6E73203D207B0A2F2F202020202020202020202020206E616D653A20226C6C6D2D616374696F6E73222C0A2F2F20202020202020202020202020616374696F6E3A2066756E6374696F6E286576656E742C20656C656D656E742C2061726773';
wwv_flow_imp.g_varchar2_table(7) := '29207B0A2F2F2020202020202020202020202020202020617065782E6974656D732E50315F43555252454E545F49442E76616C7565203D20617267732E69643B0A2F2F2020202020202020202020202020202020617065782E6576656E742E7472696767';
wwv_flow_imp.g_varchar2_table(8) := '657228646F63756D656E742C20617267732E6576656E74293B0A2F2F202020202020202020202020207D0A2F2F2020202020202020207D0A0A2F2F2020202020617065782E616374696F6E732E616464285B63617264416374696F6E735D293B0A0A2F2F';
wwv_flow_imp.g_varchar2_table(9) := '207D293B0A';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(51022305970047531328)
,p_plugin_id=>wwv_flow_imp.id(50996712494192254048)
,p_file_name=>'llm-conversations.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
