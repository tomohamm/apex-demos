prompt --application/shared_components/web_sources/generative_ai
begin
--   Manifest
--     WEB SOURCE: Generative AI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(310261554241304096)
,p_name=>'Generative AI'
,p_static_id=>'generative_ai'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(310260507633304092)
,p_remote_server_id=>wwv_flow_imp.id(32516650025279416)
,p_url_path_prefix=>'/20231130/actions/generateText'
,p_credential_id=>wwv_flow_imp.id(14515840708149392)
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(310262634782304101)
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(310263035244304101)
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(310261750591304097)
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'"compartmentId":"#COMPARTMENT_ID#",',
'"prompts":["#PROMPT#"],',
' "servingMode": {',
'    "modelId": "cohere.command",',
'    "servingType": "ON_DEMAND"',
'  },',
'"maxTokens" : 300,',
'"temperature" : 0.75',
'',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(9013845919022648)
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_web_src_operation_id=>wwv_flow_imp.id(310261750591304097)
,p_name=>'COMPARTMENT_ID'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(310262222045304099)
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_web_src_operation_id=>wwv_flow_imp.id(310261750591304097)
,p_name=>'PROMPT'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp.component_end;
end;
/
