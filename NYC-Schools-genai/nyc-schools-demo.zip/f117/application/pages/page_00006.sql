prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Learn More'
,p_alias=>'LEARN-MORE'
,p_step_title=>'Learn More'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.addEventListener("DOMContentLoaded", function() {',
'',
'if (apex.item("P6_RECENT_PROMPT_ID").getValue() ) {',
'     setTimeout(function(){',
'',
'  const textElement = document.getElementById("response-"+"&P6_RECENT_PROMPT_ID.");',
'  const multilineText = textElement.textContent.trim();',
'  textElement.textContent = ""; ',
'  $("#response-"+"&P6_RECENT_PROMPT_ID.").show();',
'  // Clear the content',
'  let currentIndex = 0;',
'',
'  function typeText() {',
'    if (currentIndex < multilineText.length) {',
'      const currentChar = multilineText.charAt(currentIndex);',
'      if (currentChar === ''\n'') {',
'        textElement.textContent += ''\n'';',
'      } else {',
'        textElement.textContent += currentChar;',
'      }',
'      currentIndex++;',
'      setTimeout(typeText, 15); // Adjust typing speed (in milliseconds)',
'      textElement.scrollTop = textElement.scrollHeight; // Scroll to bottom',
'    }',
'  }',
'        typeText();',
'',
'    },30)',
'}',
' ',
'   ',
'',
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pre {',
'    white-space: pre-wrap;       /* Since CSS 2.1 */',
'    white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */',
'    white-space: -pre-wrap;      /* Opera 4-6 */',
'    white-space: -o-pre-wrap;    /* Opera 7 */',
'    word-wrap: break-word;       /* Internet Explorer 5.5+ */',
'}',
'',
'.llm-recording{',
'    pointer-events: auto !important;',
'}',
'',
'.t-Footer {',
'    gap: 0;',
'    padding: .5rem!important;',
'}',
'',
'.t-Footer-top,.t-Footer-apex{',
'    display: none;',
'    ',
'}',
'',
'',
'#response-&P6_RECENT_PROMPT_ID.{',
'    display : none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'TOUFIQ'
,p_last_upd_yyyymmddhh24miss=>'20240109150148'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(307362625962262434)
,p_plug_name=>'Prompts & Responses'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309903345029273709)
,p_plug_display_sequence=>80
,p_query_type=>'TABLE'
,p_query_table=>'PROMPTS'
,p_query_where=>'session_id = :APP_SESSION and school_id = :P6_ID'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'asked_on asc'
,p_include_rowid_column=>false
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_LLM_CONVERSATION'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'Please enter your question below regarding school policy.'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"PROMPT": "PROMPT",',
  '"RESPONSE": "RESPONSE",',
  '"ID": "ID"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307362674451262435)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307362846455262437)
,p_name=>'PROMPT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROMPT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307363013528262438)
,p_name=>'RESPONSE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307363041339262439)
,p_name=>'SHOWSQL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SHOWSQL'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307363189901262440)
,p_name=>'ASKED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASKED_ON'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307364281839262451)
,p_name=>'SESSION_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(307364506573262453)
,p_name=>'SCHOOL_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SCHOOL_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310258981415283579)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309981029614273752)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(309865248236273684)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(310043395200273799)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(315709875382340220)
,p_plug_name=>'Prompt Contexts'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--lg'
,p_plug_template=>wwv_flow_imp.id(309948779398273734)
,p_plug_display_sequence=>2010
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48576291932115712530)
,p_plug_name=>'Question'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309960837545273741)
,p_plug_display_sequence=>120
,p_plug_display_point=>'REGION_POSITION_05'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(310330849123665490)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(48576291932115712530)
,p_button_name=>'RUN'
,p_button_static_id=>'START_RECORDING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(310041088121273796)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_button_position=>'BUTTON_END'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(315709985298340221)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(310258981415283579)
,p_button_name=>'SHOW_PROMPT_INFO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(310041088121273796)
,p_button_image_alt=>'Show Prompt Info'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(307364618218262454)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(310258981415283579)
,p_button_name=>'APPLY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(310041824488273798)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_SCHOOL_ID:&P6_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307362090286262429)
,p_name=>'P6_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307362462546262433)
,p_name=>'P6_PROMPT_CONTEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(315709875382340220)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Context'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'        ''Overview of the school : ''|| OVERVIEW_PARAGRAPH ||chr(10) || chr(13)||',
'        ''The following Language Courses are taught here : ''||LANGUAGE_CLASSES||chr(10) || chr(13)||',
'        ''The following Advanced Placement Courses are taught : ''||ADVANCEDPLACEMENT_COURSES||chr(10) || chr(13)||',
'        ''The following is the Diversity in Admimission Policy for this school: ''||diadetails||chr(10) || chr(13)||',
'        ''The below extra curricular activities are available : ''|| extracurricular_activities|| chr(10) ||chr(13)||',
'        '' The below are Public Schools Athletic League (PSAL) sports for boys: ''||PSAL_SPORTS_BOYS || chr(10) ||chr(13)||',
'        '' The below are Public Schools Athletic League (PSAL) sports for girls : ''||PSAL_SPORTS_GIRLS || chr(10) ||chr(13)||',
'        '' Other facilities in this school : ''||addtl_info1 || chr(10) ||chr(13)||',
'        '' The following academic oppurtunities are available : ''||academic_opportunities || chr(10)||chr(13)',
'',
'         as prompt_context',
'',
'FROM high_schools WHERE id = :P6_ID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307363449054262443)
,p_name=>'P6_FINAL_PROMPT'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307363699481262445)
,p_name=>'P6_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311714663611700535)
,p_name=>'P6_RECENT_PROMPT_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(315708891099340210)
,p_name=>'P6_SCHOOL_NAME'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48576305850596712604)
,p_name=>'P6_PROMPT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(48576291932115712530)
,p_prompt=>'Prompt'
,p_placeholder=>'Ask a question '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(310039030771273795)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(315710130362340222)
,p_name=>'Open Additional Info Window'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(315709985298340221)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(315710138362340223)
,p_event_id=>wwv_flow_imp.id(315710130362340222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(315709875382340220)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(307363344533262442)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare Prompt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P6_FINAL_PROMPT := apex_string.join_clobs(apex_t_clob(''<CONTEXT>'',:P6_PROMPT_CONTEXT',
'||chr(10),''<QUESTION> Based on the context above answer the following question: ''||:P6_PROMPT',
'||CHR(10),'' If this question cannot be answered based on above context say - "Information not found!"'') ,'''');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>25476410200709938
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(310342060408715051)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Generative AI Call'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_web_src_operation_id=>wwv_flow_imp.id(310261750591304097)
,p_attribute_01=>'WEB_SOURCE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28455126076162547
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(9014211461022683)
,p_page_id=>6
,p_web_src_param_id=>wwv_flow_imp.id(9013845919022648)
,p_page_process_id=>wwv_flow_imp.id(310342060408715051)
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return apex_app_setting.get_value',
'     (p_name        => ''OCI_GENAI_COMPARTMENT_ID'',',
'      p_raise_error => TRUE);'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(310342455084715052)
,p_page_id=>6
,p_web_src_param_id=>wwv_flow_imp.id(310263035244304101)
,p_page_process_id=>wwv_flow_imp.id(310342060408715051)
,p_value_type=>'ITEM'
,p_value=>'P6_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(310343337627718594)
,p_page_id=>6
,p_web_src_param_id=>wwv_flow_imp.id(310262222045304099)
,p_page_process_id=>wwv_flow_imp.id(310342060408715051)
,p_value_type=>'ITEM'
,p_value=>'P6_FINAL_PROMPT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(307363597442262444)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse & Update Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO PROMPTS (SESSION_ID, SCHOOL_ID, PROMPT, RESPONSE, ASKED_ON) ',
'VALUES (:APP_SESSION, :P6_ID, :P6_PROMPT, (SELECT LLM_OUTPUT',
'        FROM',
'            JSON_TABLE ( :P6_RESPONSE, ''$.generatedTexts[0][0]''',
'                COLUMNS',
'                    LLM_OUTPUT clob PATH ''$.text''',
'            ) ',
'), systimestamp) returnING id into :P6_RECENT_PROMPT_ID;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>25476663109709940
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(315708972139340211)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize Items'
,p_process_sql_clob=>'SELECT SCHOOL_NAME into :P6_SCHOOL_NAME FROM HIGH_SCHOOLS WHERE ID = :P6_ID;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>33822037806787707
);
wwv_flow_imp.component_end;
end;
/
