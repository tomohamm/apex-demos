prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Email Redirect'
,p_alias=>'EMAIL-REDIRECT'
,p_step_title=>'Email Redirect'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_rejoin_existing_sessions=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'TOUFIQ'
,p_last_upd_yyyymmddhh24miss=>'20230908182025'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(291956471680841564)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(319979445406193737)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(319863664028193669)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(320041810992193784)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(291107882773598808)
,p_branch_name=>'Go To Page 10'
,p_branch_action=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp.component_end;
end;
/
