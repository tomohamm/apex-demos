prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Apply to School'
,p_alias=>'APPLY-TO-SCHOOL'
,p_page_mode=>'MODAL'
,p_step_title=>'Apply to School'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#script#MIN#.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'typeEffect("P7_LETTER", apex.item("P7_EMAIL_HIDDEN").getValue());',
'  '))
,p_step_template=>wwv_flow_imp.id(319864532596193669)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'TOUFIQ'
,p_last_upd_yyyymmddhh24miss=>'20240110165243'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(291108326607598812)
,p_plug_name=>'Prompt Context'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(319951770057193722)
,p_plug_display_sequence=>2010
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321713576575620525)
,p_plug_name=>'Final Actions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(319903244782193695)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(324411708423495890)
,p_plug_name=>'Application Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(319900412297193693)
,p_plug_display_sequence=>120
,p_query_type=>'TABLE'
,p_query_table=>'NYC_SCHOOLS_APPS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(321710535721620494)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(321713576575620525)
,p_button_name=>'SEND_APP'
,p_button_static_id=>'send_app'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(320040270498193783)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Application'
,p_button_css_classes=>'u-hidden'
,p_icon_css_classes=>'fa-send'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(321712827670620517)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_button_name=>'GEN_LETTER'
,p_button_static_id=>'gen_letter'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(320040240280193783)
,p_button_image_alt=>'Generate Letter'
,p_icon_css_classes=>'fa-repeat'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(325707495313260197)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(321713576575620525)
,p_button_name=>'SHOW_PROMPT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(320039503913193781)
,p_button_image_alt=>'Show Prompt'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P7_PROMPT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(324413442037495907)
,p_branch_name=>'reload page'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_STUDENT_NAME,P7_SCHOOL_ID,P7_PROMPT:&P7_STUDENT_NAME.,&P7_SCHOOL_ID.,&P7_PROMPT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(321712827670620517)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(324414749226495920)
,p_branch_name=>'go to applications'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9565957608894139)
,p_name=>'P7_ADMIN_EMAIL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'select email from APEX_WORKSPACE_APEX_USERS where user_name= ''NYC.ADMIN'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254319055425292682)
,p_name=>'P7_PARENT_USER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'PARENT_USER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(291107252586598801)
,p_name=>'P7_TASK_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(291107395327598803)
,p_name=>'P7_URL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321710307047620492)
,p_name=>'P7_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321711147769620500)
,p_name=>'P7_SCHOOL_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'SCHOOL_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321711984265620509)
,p_name=>'P7_EMAIL_HIDDEN'
,p_data_type=>'CLOB'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324411860192495892)
,p_name=>'P7_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324411988190495893)
,p_name=>'P7_PARENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_default=>'select initcap(first_name) || '' '' || initcap(last_name) from APEX_WORKSPACE_APEX_USERS where user_name=:APP_USER;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Parent Name'
,p_source=>'PARENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(320037742833193780)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412067939495894)
,p_name=>'P7_PARENT_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_default=>'select email from APEX_WORKSPACE_APEX_USERS where user_name=:APP_USER;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Parent Email'
,p_source=>'PARENT_EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(320037742833193780)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412247563495895)
,p_name=>'P7_STUDENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_prompt=>'Student Name'
,p_source=>'STUDENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(320039034289193781)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412300518495896)
,p_name=>'P7_STUDENT_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'STUDENT_EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412374854495897)
,p_name=>'P7_LETTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_prompt=>'Letter'
,p_source=>'LETTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>15
,p_field_template=>wwv_flow_imp.id(320037742833193780)
,p_item_css_classes=>'u-hidden'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412511014495898)
,p_name=>'P7_DISPOSITION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_default=>'NEW'
,p_source=>'DISPOSITION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412570160495899)
,p_name=>'P7_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412704067495900)
,p_name=>'P7_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324412756429495901)
,p_name=>'P7_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324415916837495932)
,p_name=>'P7_PROMPT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_source_plug_id=>wwv_flow_imp.id(324411708423495890)
,p_item_default=>'P7_FINAL_PROMPT'
,p_item_default_type=>'ITEM'
,p_source=>'PROMPT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324415952892495933)
,p_name=>'P7_FINAL_PROMPT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(291108326607598812)
,p_prompt=>'Prompt Context'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(320037742833193780)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(324413144902495904)
,p_name=>'enable gen letter button'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_STUDENT_NAME,P7_STUDENT_EMAIL'
,p_condition_element=>'P7_STUDENT_NAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324413488250495908)
,p_event_id=>wwv_flow_imp.id(324413144902495904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_LETTER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324413183108495905)
,p_event_id=>wwv_flow_imp.id(324413144902495904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#gen_letter'').removeAttr(''disabled'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324413643492495909)
,p_event_id=>wwv_flow_imp.id(324413144902495904)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_LETTER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324413250854495906)
,p_event_id=>wwv_flow_imp.id(324413144902495904)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#gen_letter'').attr(''disabled'',''disabled'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(324413713690495910)
,p_name=>'Control UI if letter generated'
,p_event_sequence=>30
,p_condition_element=>'P7_PROMPT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324414188550495915)
,p_event_id=>wwv_flow_imp.id(324413713690495910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'hide Gen button'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(321712827670620517)
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(324413785388495911)
,p_event_id=>wwv_flow_imp.id(324413713690495910)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'show UI components'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P7_PROMPT_CONTAINER,#P7_LETTER_CONTAINER,#send_app'').removeClass(''u-hidden'');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(325707586983260198)
,p_name=>'Show Prompt DA'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(325707495313260197)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(291108440037598813)
,p_event_id=>wwv_flow_imp.id(325707586983260198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(291108326607598812)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321712693565620516)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'AI Call'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(321712827670620517)
,p_internal_uid=>29827343441148027
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(324414777538495921)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Submit Application'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(321710535721620494)
,p_process_success_message=>'Your School Application has been submitted!'
,p_internal_uid=>32529427414023432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(324411810945495891)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(324411708423495890)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Email Application'
,p_internal_uid=>32526460821023402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(291107296533598802)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(321712866827620518)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare URL for Email'
,p_process_sql_clob=>':P7_URL := apex_util.host_url||APEX_PAGE.GET_URL (p_page => 14, p_items => ''EMAIL_TASK_ID'', p_values => :P7_TASK_ID, P_REQUEST => ''OPEN_EMAIL_TASK'', p_session => 0, p_plain_url => TRUE);'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>33824429753787731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321710707068620496)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(321712866827620518)
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'Send E-Mail'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&P7_ADMIN_EMAIL.'
,p_attribute_03=>'&P7_PARENT_EMAIL.'
,p_attribute_10=>'Y'
,p_attribute_11=>wwv_flow_imp.id(291915426444331151)
,p_attribute_12=>'{"SUBJECT":"Application received from &P7_PARENT_NAME.","BODY":"&P7_LETTER.","ICON_URL":"https://jb7mfvfk4wteln6-aiinapex.adb.us-ashburn-1.oraclecloudapps.com/ords/r/ai_apex/104/files/static/v11/icons/app-icon-144-rounded.png","TITLE":"High School Ap'
||'plication","APP_LINK":"&P7_URL."}'
,p_process_success_message=>'and sent successfully.'
,p_internal_uid=>29825356944148007
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321713400881620523)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(321712693565620516)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare Prompt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    L_SCHOOL_NAME HIGH_SCHOOLS.SCHOOL_NAME%TYPE;',
'    L_PROMPT CLOB;',
'BEGIN',
'    SELECT SCHOOL_NAME INTO L_SCHOOL_NAME FROM HIGH_SCHOOLS WHERE ID = :P7_SCHOOL_ID;',
'    L_PROMPT :=',
'        q''[',
'As a parent of a kid who is seeking admission to a school, write an E-mail applying to a school.',
'Use the below info.',
'',
'Parent Name : ]''|| :P7_PARENT_NAME||chr(10)||chr(13) ||q''[',
'Applicant Name : ]''|| :P7_STUDENT_NAME||chr(10)||chr(13) ||q''[',
'School Name : ]''|| initcap(L_SCHOOL_NAME)||chr(10)||chr(13);',
'',
'IF :P3_METHOD IS NOT NULL or :P3_ATTENDANCE_RATE IS NOT NULL or :P3_INTEREST IS NOT NULL THEN ',
'    L_PROMPT := L_PROMPT || ',
'    q''[',
'Try and include below details in the email:]''||chr(10)||chr(13);',
'end if;',
'',
'IF :P3_METHOD IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'I am selecting this school because it has mention the method of screenings : &P3_METHOD. (NOTE: Multiple values are seperated by : )''||chr(10)||chr(13);',
'END IF;',
'',
'IF :P3_ATTENDANCE_RATE IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'I am selecting this school because it has mention the attendance criteria : &P3_ATTENDANCE_RATE. ''||chr(10)||chr(13);',
'END IF;',
'',
'IF :P3_INTEREST IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'The student is interested in the following areas : &P3_INTEREST. (NOTE: Multiple values are seperated by a colon. If its a:b read it as a & b) ''||chr(10)||chr(13);',
'END IF;',
'-- Attendance Rate : &P3_ATTENDANCE_RATE.',
'-- Safety rating : &P3_SAFE.',
'-- ',
'-- Do include these filter criteria mandatorily.',
'-- '';',
':P7_FINAL_PROMPT := L_PROMPT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29828050757148034
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321716392184631834)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(321712693565620516)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Generative AI Call'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(320259970033224081)
,p_web_src_operation_id=>wwv_flow_imp.id(320260166383224082)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>29831042060159345
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(19013167536942669)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(19012261710942633)
,p_page_process_id=>wwv_flow_imp.id(321716392184631834)
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return apex_app_setting.get_value',
'     (p_name        => ''OCI_GENAI_COMPARTMENT_ID'',',
'      p_raise_error => TRUE);'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(321716824025631836)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(320261451036224086)
,p_page_process_id=>wwv_flow_imp.id(321716392184631834)
,p_value_type=>'ITEM'
,p_value=>'P7_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(321717347313631837)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(320260637837224084)
,p_page_process_id=>wwv_flow_imp.id(321716392184631834)
,p_value_type=>'ITEM'
,p_value=>'P7_FINAL_PROMPT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321713001017620519)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(321712866827620518)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'P7_EMAIL NULL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P7_EMAIL_HIDDEN := null;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29827650893148030
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321717704349632980)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(321712693565620516)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse & Update Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LLM_OUTPUT INTO :P7_EMAIL_HIDDEN',
'        FROM',
'            JSON_TABLE ( :P7_RESPONSE, ''$.generatedTexts[0][0]''',
'                COLUMNS',
'                    LLM_OUTPUT clob PATH ''$.text''',
'            );'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29832354225160491
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(324414397157495917)
,p_process_sequence=>40
,p_region_id=>wwv_flow_imp.id(324411708423495890)
,p_parent_process_id=>wwv_flow_imp.id(324414777538495921)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Insert Application Details'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_when_button_id=>wwv_flow_imp.id(321710535721620494)
,p_process_success_message=>'Application saved'
,p_internal_uid=>32529047033023428
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(324416360856495937)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(321712866827620518)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Push email queue'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_pwa.push_queue;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>32531010732023448
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(324414547129495918)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(324414777538495921)
,p_process_type=>'NATIVE_CREATE_TASK'
,p_process_name=>'Create Application Task'
,p_attribute_01=>wwv_flow_imp.id(324471764663354801)
,p_attribute_04=>'P7_TASK_ID'
,p_attribute_05=>'P7_ID'
,p_process_when_button_id=>wwv_flow_imp.id(321710535721620494)
,p_internal_uid=>32529197005023429
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(321712866827620518)
,p_process_sequence=>60
,p_parent_process_id=>wwv_flow_imp.id(324414777538495921)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Send Email'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_process_when_button_id=>wwv_flow_imp.id(321710535721620494)
,p_process_success_message=>'and submitted!'
,p_internal_uid=>29827516703148029
);
wwv_flow_imp.component_end;
end;
/
