prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Apply to School'
,p_alias=>'APPLY-TO-SCHOOL'
,p_page_mode=>'MODAL'
,p_step_title=>'Apply to School'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#script#MIN#.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'typeEffect("P7_LETTER", apex.item("P7_EMAIL_HIDDEN").getValue());',
'  '))
,p_step_template=>wwv_flow_imp.id(309866116804273684)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'TOUFIQ'
,p_last_upd_yyyymmddhh24miss=>'20240109144539'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(281109910815678827)
,p_plug_name=>'Prompt Context'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(309953354265273737)
,p_plug_display_sequence=>2010
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311715160783700540)
,p_plug_name=>'Final Actions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309904828990273710)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(314413292631575905)
,p_plug_name=>'Application Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309901996505273708)
,p_plug_display_sequence=>120
,p_query_type=>'TABLE'
,p_query_table=>'NYC_SCHOOLS_APPS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(311712119929700509)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(311715160783700540)
,p_button_name=>'SEND_APP'
,p_button_static_id=>'send_app'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(310041854706273798)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Application'
,p_button_css_classes=>'u-hidden'
,p_icon_css_classes=>'fa-send'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(311714411878700532)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_button_name=>'GEN_LETTER'
,p_button_static_id=>'gen_letter'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(310041824488273798)
,p_button_image_alt=>'Generate Letter'
,p_icon_css_classes=>'fa-repeat'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(315709079521340212)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(311715160783700540)
,p_button_name=>'SHOW_PROMPT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(310041088121273796)
,p_button_image_alt=>'Show Prompt'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P7_PROMPT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(314415026245575922)
,p_branch_name=>'reload page'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_STUDENT_NAME,P7_SCHOOL_ID,P7_PROMPT:&P7_STUDENT_NAME.,&P7_SCHOOL_ID.,&P7_PROMPT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(311714411878700532)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(314416333434575935)
,p_branch_name=>'go to applications'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244320639633372697)
,p_name=>'P7_PARENT_USER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'PARENT_USER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(281108836794678816)
,p_name=>'P7_TASK_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(281108979535678818)
,p_name=>'P7_URL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311711891255700507)
,p_name=>'P7_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311712731977700515)
,p_name=>'P7_SCHOOL_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'SCHOOL_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311713568473700524)
,p_name=>'P7_EMAIL_HIDDEN'
,p_data_type=>'CLOB'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413444400575907)
,p_name=>'P7_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413572398575908)
,p_name=>'P7_PARENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_default=>'select initcap(first_name) || '' '' || initcap(last_name) from APEX_WORKSPACE_APEX_USERS where user_name=:APP_USER;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Parent Name'
,p_source=>'PARENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413652147575909)
,p_name=>'P7_PARENT_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_default=>'select email from APEX_WORKSPACE_APEX_USERS where user_name=:APP_USER;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Parent Email'
,p_source=>'PARENT_EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413831771575910)
,p_name=>'P7_STUDENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_prompt=>'Student Name'
,p_source=>'STUDENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(310040618497273796)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413884726575911)
,p_name=>'P7_STUDENT_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'STUDENT_EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314413959062575912)
,p_name=>'P7_LETTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_prompt=>'Letter'
,p_source=>'LETTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>15
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_css_classes=>'u-hidden'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314414095222575913)
,p_name=>'P7_DISPOSITION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_default=>'NEW'
,p_source=>'DISPOSITION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314414154368575914)
,p_name=>'P7_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314414288275575915)
,p_name=>'P7_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314414340637575916)
,p_name=>'P7_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314417501045575947)
,p_name=>'P7_PROMPT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_source_plug_id=>wwv_flow_imp.id(314413292631575905)
,p_item_default=>'P7_FINAL_PROMPT'
,p_item_default_type=>'ITEM'
,p_source=>'PROMPT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314417537100575948)
,p_name=>'P7_FINAL_PROMPT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(281109910815678827)
,p_prompt=>'Prompt Context'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314414729110575919)
,p_name=>'enable gen letter button'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_STUDENT_NAME,P7_STUDENT_EMAIL'
,p_condition_element=>'P7_STUDENT_NAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314415072458575923)
,p_event_id=>wwv_flow_imp.id(314414729110575919)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_LETTER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314414767316575920)
,p_event_id=>wwv_flow_imp.id(314414729110575919)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#gen_letter'').removeAttr(''disabled'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314415227700575924)
,p_event_id=>wwv_flow_imp.id(314414729110575919)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_LETTER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314414835062575921)
,p_event_id=>wwv_flow_imp.id(314414729110575919)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#gen_letter'').attr(''disabled'',''disabled'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314415297898575925)
,p_name=>'Control UI if letter generated'
,p_event_sequence=>30
,p_condition_element=>'P7_PROMPT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314415772758575930)
,p_event_id=>wwv_flow_imp.id(314415297898575925)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'hide Gen button'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(311714411878700532)
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314415369596575926)
,p_event_id=>wwv_flow_imp.id(314415297898575925)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'show UI components'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P7_PROMPT_CONTAINER,#P7_LETTER_CONTAINER,#send_app'').removeClass(''u-hidden'');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(315709171191340213)
,p_name=>'Show Prompt DA'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(315709079521340212)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(281110024245678828)
,p_event_id=>wwv_flow_imp.id(315709171191340213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281109910815678827)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311714277773700531)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'AI Call'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(311714411878700532)
,p_internal_uid=>29827343441148027
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314416361746575936)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Submit Application'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(311712119929700509)
,p_process_success_message=>'Your School Application has been submitted!'
,p_internal_uid=>32529427414023432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314413395153575906)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(314413292631575905)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Email Application'
,p_internal_uid=>32526460821023402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(281108880741678817)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(311714451035700533)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare URL for Email'
,p_process_sql_clob=>':P7_URL := apex_util.host_url || ''/ords/r/ai_apex/high-schools/email-redirect?EMAIL_TASK_ID=''||:P7_TASK_ID||''&request=OPEN_EMAIL_TASK&session=0'';'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>33824429753787731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311712291276700511)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(311714451035700533)
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'Send E-Mail'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'schooladm.ocw@gmail.com '
,p_attribute_03=>'&P7_PARENT_EMAIL.'
,p_attribute_10=>'Y'
,p_attribute_11=>wwv_flow_imp.id(281917010652411166)
,p_attribute_12=>'{"SUBJECT":"Application received from &P7_PARENT_NAME.","BODY":"&P7_LETTER.","ICON_URL":"https://jb7mfvfk4wteln6-aiinapex.adb.us-ashburn-1.oraclecloudapps.com/ords/r/ai_apex/104/files/static/v11/icons/app-icon-144-rounded.png","TITLE":"High School Ap'
||'plication","APP_LINK":"&P7_URL."}'
,p_process_success_message=>'and sent successfully.'
,p_internal_uid=>29825356944148007
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311714985089700538)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(311714277773700531)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare Prompt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    L_SCHOOL_NAME HIGH_SCHOOLS.SCHOOL_NAME%TYPE;',
'    L_PROMPT CLOB;',
'BEGIN',
'    SELECT SCHOOL_NAME INTO L_SCHOOL_NAME FROM HIGH_SCHOOLS WHERE ID = :P7_SCHOOL_ID;',
'    L_PROMPT :=',
'        q''[',
'As a parent of a kid who is seeking admission to a school, write an E-mail applying to a school.',
'Use the below info.',
'',
'Parent Name : ]''|| :P7_PARENT_NAME||chr(10)||chr(13) ||q''[',
'Applicant Name : ]''|| :P7_STUDENT_NAME||chr(10)||chr(13) ||q''[',
'School Name : ]''|| initcap(L_SCHOOL_NAME)||chr(10)||chr(13);',
'',
'IF :P3_METHOD IS NOT NULL or :P3_ATTENDANCE_RATE IS NOT NULL or :P3_INTEREST IS NOT NULL THEN ',
'    L_PROMPT := L_PROMPT || ',
'    q''[',
'Try and include below details in the email:]''||chr(10)||chr(13);',
'end if;',
'',
'IF :P3_METHOD IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'I am selecting this school because it has mention the method of screenings : &P3_METHOD. (NOTE: Multiple values are seperated by : )''||chr(10)||chr(13);',
'END IF;',
'',
'IF :P3_ATTENDANCE_RATE IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'I am selecting this school because it has mention the attendance criteria : &P3_ATTENDANCE_RATE. ''||chr(10)||chr(13);',
'END IF;',
'',
'IF :P3_INTEREST IS NOT NULL THEN',
'    L_PROMPT := L_PROMPT ||''',
'The student is interested in the following areas : &P3_INTEREST. (NOTE: Multiple values are seperated by a colon. If its a:b read it as a & b) ''||chr(10)||chr(13);',
'END IF;',
'-- Attendance Rate : &P3_ATTENDANCE_RATE.',
'-- Safety rating : &P3_SAFE.',
'-- ',
'-- Do include these filter criteria mandatorily.',
'-- '';',
':P7_FINAL_PROMPT := L_PROMPT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29828050757148034
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311717976392711849)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(311714277773700531)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Generative AI Call'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(310261554241304096)
,p_web_src_operation_id=>wwv_flow_imp.id(310261750591304097)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>29831042060159345
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(9014751745022684)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(9013845919022648)
,p_page_process_id=>wwv_flow_imp.id(311717976392711849)
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return apex_app_setting.get_value',
'     (p_name        => ''OCI_GENAI_COMPARTMENT_ID'',',
'      p_raise_error => TRUE);'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(311718408233711851)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(310263035244304101)
,p_page_process_id=>wwv_flow_imp.id(311717976392711849)
,p_value_type=>'ITEM'
,p_value=>'P7_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(311718931521711852)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(310262222045304099)
,p_page_process_id=>wwv_flow_imp.id(311717976392711849)
,p_value_type=>'ITEM'
,p_value=>'P7_FINAL_PROMPT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311714585225700534)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(311714451035700533)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'P7_EMAIL NULL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P7_EMAIL_HIDDEN := null;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29827650893148030
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311719288557712995)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(311714277773700531)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse & Update Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LLM_OUTPUT INTO :P7_EMAIL_HIDDEN',
'        FROM',
'            JSON_TABLE ( :P7_RESPONSE, ''$.generatedTexts[0][0]''',
'                COLUMNS',
'                    LLM_OUTPUT clob PATH ''$.text''',
'            );'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29832354225160491
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314415981365575932)
,p_process_sequence=>40
,p_region_id=>wwv_flow_imp.id(314413292631575905)
,p_parent_process_id=>wwv_flow_imp.id(314416361746575936)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Insert Application Details'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_when_button_id=>wwv_flow_imp.id(311712119929700509)
,p_process_success_message=>'Application saved'
,p_internal_uid=>32529047033023428
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314417945064575952)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(311714451035700533)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Push email queue'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_pwa.push_queue;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>32531010732023448
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314416131337575933)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(314416361746575936)
,p_process_type=>'NATIVE_CREATE_TASK'
,p_process_name=>'Create Application Task'
,p_attribute_01=>wwv_flow_imp.id(314473348871434816)
,p_attribute_04=>'P7_TASK_ID'
,p_attribute_05=>'P7_ID'
,p_process_when_button_id=>wwv_flow_imp.id(311712119929700509)
,p_internal_uid=>32529197005023429
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311714451035700533)
,p_process_sequence=>60
,p_parent_process_id=>wwv_flow_imp.id(314416361746575936)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Send Email'
,p_attribute_01=>'N'
,p_attribute_08=>'WAIT'
,p_attribute_09=>'Y'
,p_process_when_button_id=>wwv_flow_imp.id(311712119929700509)
,p_process_success_message=>'and submitted!'
,p_internal_uid=>29827516703148029
);
wwv_flow_imp.component_end;
end;
/
