prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(320151801811193877)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(325558096081864059)
,p_group_name=>'User Settings'
);
wwv_flow_imp.component_end;
end;
/
