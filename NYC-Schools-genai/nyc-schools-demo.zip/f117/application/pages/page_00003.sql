prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Search & Apply'
,p_alias=>'SEARCH-APPLY'
,p_step_title=>'Search & Apply'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var refocusMap = false;',
'$("#tabs").on("atabsactivate", function(event, ui) {',
'',
'',
'   if (apex.region("tabs").widget().aTabs("getActive").href == "#SR_map" && refocusMap){',
'       refocusMap = false;',
'        setTimeout(function(){',
'           apex.region( "map" ).reset();',
'       }, 500);',
'   }',
'   ',
'});'))
,p_step_template=>wwv_flow_imp.id(309868946262273686)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20230919182920'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310175615434273918)
,p_plug_name=>'Search'
,p_region_name=>'SEARCH_CARDS'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(309968578150273745)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(310175436737273917)
,p_landmark_label=>'Filters'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_10=>'Total Schools'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310178352004273922)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(309904828990273710)
,p_plug_display_sequence=>10
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310187169372273931)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309981029614273752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(309865248236273684)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(310043395200273799)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311716599626700554)
,p_plug_name=>'Tabs'
,p_region_name=>'tabs'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(309978340055273751)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311716353855700552)
,p_plug_name=>'Cards'
,p_region_name=>'cards'
,p_parent_plug_id=>wwv_flow_imp.id(311716599626700554)
,p_region_template_options=>'#DEFAULT#:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(309903345029273709)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310175436737273917)
,p_plug_name=>'High Schools'
,p_parent_plug_id=>wwv_flow_imp.id(311716353855700552)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309909055439273712)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       BOROUGH,',
'       SCHOOL_NAME,',
'       NEIGHBORHOOD,',
'       INTEREST,',
'       METHOD,',
'       TOTAL_STUDENTS,',
'       GRADUATION_RATE,',
'       ATTENDANCE_RATE,',
'       COLLEGE_CAREER_RATE,',
'       SAFE,',
'       SEATS,',
'       APPLICANTS,',
'       DBN,',
'       LATITUDE,',
'       LONGITUDE,',
'       LANGUAGE_CLASSES,',
'       ADVANCED_PLACEMENT_COURSES,',
'       SCHOOL_SPORTS,',
'       FAQ_URL,',
'       OVERVIEW_PARAGRAPH',
'       ,',
'       (select case when DISPOSITION=''NEW'' then ''PENDING'' else DISPOSITION end ',
'       from nyc_schools_apps where school_id=hs.id and parent_user=:APP_USER fetch first 1 rows only)',
'         DISPOSITION',
'         ,',
'       (select case DISPOSITION WHEN ''NEW'' then ''u-warning'' WHEN ''APPROVED'' then ''u-success'' when ''REJECTED'' then ''u-danger'' else ''u-info'' end',
'        from nyc_schools_apps where school_id=hs.id and parent_user=:APP_USER fetch first 1 rows only)',
'        DISPOSITION_CSS',
'         ,    ',
'       (select task_id from APEX_TASKS where application_id=:APP_ID and ',
'            detail_pk= (select id from nyc_schools_apps where school_id=hs.id and parent_user=:APP_USER  fetch first 1 rows only))',
'        TASK_ID,',
'        ',
'        sdo_geom.sdo_distance(',
'          sdo_geometry(2001, 4326, sdo_point_type(longitude, latitude, null), null, null),',
'          sdo_geometry(2001, 4326, sdo_point_type(:P0_CUR_LONG, :P0_CUR_LAT, null), null, null),',
'          0.01,',
'          ''unit=MILE''',
'        ) DISTANCE_MILES',
'  from HIGH_SCHOOLS hs',
'  where ',
'  (',
'      :P3_APPLIED_ONLY=''Y'' and (select count(id) from nyc_schools_apps where school_id=hs.id and parent_user=:APP_USER)>0',
'      ) ',
'      or :P3_APPLIED_ONLY=''N'''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P0_CUR_LONG,P0_CUR_LAT,P3_APPLIED_ONLY'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(307363982849262448)
,p_region_id=>wwv_flow_imp.id(310175436737273917)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'SCHOOL_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'INTEREST'
,p_body_adv_formatting=>false
,p_body_column_name=>'NEIGHBORHOOD'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'BOROUGH'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(314416846004575941)
,p_card_id=>wwv_flow_imp.id(307363982849262448)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'&DISPOSITION.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:9:P8_TASK_ID:&TASK_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'&DISPOSITION_CSS.'
,p_is_hot=>false
,p_condition_type=>'EXISTS'
,p_condition_expr1=>'select 1 from nyc_schools_apps where school_id=:ID and parent_user=:APP_USER'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(307364054835262449)
,p_card_id=>wwv_flow_imp.id(307363982849262448)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Apply'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_SCHOOL_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
,p_condition_type=>'NOT_EXISTS'
,p_condition_expr1=>'select 1 from nyc_schools_apps where school_id=:ID and parent_user=:APP_USER'
,p_exec_cond_for_each_row=>true
,p_authorization_scheme=>'!'||wwv_flow_imp.id(310153062540273891)
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(307364190757262450)
,p_card_id=>wwv_flow_imp.id(307363982849262448)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'Ask Questions'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_ID:&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-question-square-o'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376913694935063847)
,p_plug_name=>'Map'
,p_region_name=>'map'
,p_parent_plug_id=>wwv_flow_imp.id(311716599626700554)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(309901996505273708)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       BOROUGH,',
'       SCHOOL_NAME,',
'       NEIGHBORHOOD,',
'       INTEREST,',
'       METHOD,',
'       TOTAL_STUDENTS,',
'       GRADUATION_RATE,',
'       ATTENDANCE_RATE,',
'       COLLEGE_CAREER_RATE,',
'       SAFE,',
'       SEATS,',
'       APPLICANTS,',
'       DBN,',
'       LATITUDE,',
'       LONGITUDE,',
'       LANGUAGE_CLASSES,',
'       ADVANCED_PLACEMENT_COURSES,',
'       SCHOOL_SPORTS,',
'       FAQ_URL,',
'       OVERVIEW_PARAGRAPH',
'       ,',
'       (select case when DISPOSITION=''NEW'' then ''Pending'' else DISPOSITION end from nyc_schools_apps where school_id=hs.id and parent_name=initcap(:APP_USER))',
'         DISPOSITION',
'         ,    ',
'       (select task_id from APEX_TASKS where application_id=:APP_ID and ',
'            detail_pk= (select id from nyc_schools_apps where school_id=hs.id and parent_name=initcap(:APP_USER)))',
'        TASK_ID,',
'        sdo_geom.sdo_distance(',
'  sdo_geometry(2001, 4326, sdo_point_type(longitude, latitude, null), null, null),',
'  sdo_geometry(2001, 4326, sdo_point_type(:P0_CUR_LONG, :P0_CUR_LAT, null), null, null),',
'  0.01,',
'  ''unit=MILE''',
') DISTANCE_MILES',
'  from HIGH_SCHOOLS hs where',
'    (',
'      :P3_APPLIED_ONLY=''Y'' and (select count(id) from nyc_schools_apps where school_id=hs.id and parent_user=:APP_USER)>0',
'      ) ',
'      or :P3_APPLIED_ONLY=''N'''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_ajax_items_to_submit=>'P0_CUR_LAT,P0_CUR_LONG,P3_APPLIED_ONLY'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(315695938383274352)
,p_region_id=>wwv_flow_imp.id(376913694935063847)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:CIRCLE_TOOL:DISTANCE_TOOL'
,p_unit_system=>'IMPERIAL'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(315696497340274355)
,p_map_region_id=>wwv_flow_imp.id(315695938383274352)
,p_name=>'Schools'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Circle'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&SCHOOL_NAME.</strong><br>',
'Borough: &BOROUGH.<br'))
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'SCHOOL_NAME'
,p_info_window_body_column=>'BOROUGH'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(315697089193274357)
,p_map_region_id=>wwv_flow_imp.id(315695938383274352)
,p_name=>'Current Position'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'SELECT TO_NUMBER(:P0_CUR_LAT) AS LATITUDE, TO_NUMBER(:P0_CUR_LONG) AS LONGTITUDE FROM DUAL;'
,p_items_to_submit=>'P0_CUR_LAT,P0_CUR_LONG'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGTITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#970909'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Home'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'You are here!'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376917828692109793)
,p_plug_name=>'Search - Maps'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(309968578150273745)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(376913694935063847)
,p_landmark_label=>'Filters'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_10=>'Total Schools'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(310178898369273923)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(310178352004273922)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(310041854706273798)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:RR,3::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(247305170688305048)
,p_name=>'P3_APPLIED_ONLY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(310178352004273922)
,p_item_display_point=>'NEXT'
,p_item_default=>'N'
,p_prompt=>'Applied Only'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(310039327041273795)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310176095999273918)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Search'
,p_source=>'BOROUGH,SCHOOL_NAME,NEIGHBORHOOD,INTEREST,METHOD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_attribute_04=>'N'
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310176458415273919)
,p_name=>'P3_METHOD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Method'
,p_source=>'METHOD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310176914627273919)
,p_name=>'P3_BOROUGH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Borough'
,p_source=>'BOROUGH'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310177326255273919)
,p_name=>'P3_INTEREST'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Interest'
,p_source=>'INTEREST'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310177683033273921)
,p_name=>'P3_ATTENDANCE_RATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Attendance Rate'
,p_source=>'ATTENDANCE_RATE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<50;|50,50 - 84;50|84,84 - 87;84|87,87 - 90;87|90,>=90;90|'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310178095471273922)
,p_name=>'P3_SAFE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Safe'
,p_source=>'SAFE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<50;|50,50 - 80;50|80,80 - 84;80|84,84 - 90;84|90,>=90;90|'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311716077574700549)
,p_name=>'P3_DISTANCE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(310175615434273918)
,p_prompt=>'Distance'
,p_source=>'DISTANCE_MILES'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<5 miles;|5,5 - 10 miles;5|10,10 - 15 miles;10|15,15 - 20 miles;15|20,>=20 miles;20|'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(345531109780468331)
,p_name=>'P3_DISTANCE_MAP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Distance'
,p_source=>'DISTANCE_MILES'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:< 5 miles;|5,5 - 10 miles;5|10,10 - 15 miles;10|15,15 - 20 miles;15|20,>= 20 miles;20|'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>false
,p_fc_zero_count_entries=>'L'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376925129262109849)
,p_name=>'P3_SEARCH_MAP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Search'
,p_source=>'BOROUGH,SCHOOL_NAME,NEIGHBORHOOD,INTEREST,METHOD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376925491678109850)
,p_name=>'P3_METHOD_MAP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Method'
,p_source=>'METHOD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376925947890109850)
,p_name=>'P3_BOROUGH_MAP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Borough'
,p_source=>'BOROUGH'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376926359518109850)
,p_name=>'P3_INTEREST_MAP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Interest'
,p_source=>'INTEREST'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376926716296109852)
,p_name=>'P3_ATTENDANCE_RATE_MAP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Attendance Rate'
,p_source=>'ATTENDANCE_RATE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<50;|50,50 - 84;50|84,84 - 87;84|87,87 - 90;87|90,>=90;90|'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376927128734109853)
,p_name=>'P3_SAFE_MAP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(376917828692109793)
,p_prompt=>'Safe'
,p_source=>'SAFE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<50;|50,50 - 80;50|80,80 - 84;80|84,84 - 90;84|90,>=90;90|'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(315708372267340205)
,p_name=>'Update Maps Facet'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(310175615434273918)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'facetschange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(315708522968340206)
,p_event_id=>wwv_flow_imp.id(315708372267340205)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'refocusMap = true;',
'if (apex.item("P3_SEARCH").getValue() != apex.item("P3_SEARCH_MAP").getValue()){',
'    apex.item("P3_SEARCH_MAP").setValue(apex.item("P3_SEARCH").getValue());',
'}',
'',
'if (apex.item("P3_METHOD").getValue() != apex.item("P3_METHOD_MAP").getValue()){',
'    apex.item("P3_METHOD_MAP").setValue(apex.item("P3_METHOD").getValue());',
'}',
'',
'if (apex.item("P3_DISTANCE").getValue() != apex.item("P3_DISTANCE_MAP").getValue()){',
'    apex.item("P3_DISTANCE_MAP").setValue(apex.item("P3_DISTANCE").getValue());',
'}',
'',
'if (apex.item("P3_BOROUGH").getValue() != apex.item("P3_BOROUGH_MAP").getValue()){',
'    apex.item("P3_BOROUGH_MAP").setValue(apex.item("P3_BOROUGH").getValue());',
'}',
'',
'if (apex.item("P3_INTEREST").getValue() != apex.item("P3_INTEREST_MAP").getValue()){',
'    apex.item("P3_INTEREST_MAP").setValue(apex.item("P3_INTEREST").getValue());',
'}',
'',
'if (apex.item("P3_ATTENDANCE_RATE").getValue() != apex.item("P3_ATTENDANCE_RATE_MAP").getValue()){',
'    apex.item("P3_ATTENDANCE_RATE_MAP").setValue(apex.item("P3_ATTENDANCE_RATE").getValue());',
'}',
'',
'if (apex.item("P3_SAFE").getValue() != apex.item("P3_SAFE_MAP").getValue()){',
'    apex.item("P3_SAFE_MAP").setValue(apex.item("P3_SAFE").getValue());',
'}',
'',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(315708621415340207)
,p_name=>'Hide Maps Facted Search Region'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(315708710311340208)
,p_event_id=>wwv_flow_imp.id(315708621415340207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(376917828692109793)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(247305280878305049)
,p_name=>'show only applied?'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_APPLIED_ONLY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(247305326359305050)
,p_event_id=>wwv_flow_imp.id(247305280878305049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(310175436737273917)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(247305471371305051)
,p_event_id=>wwv_flow_imp.id(247305280878305049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(376913694935063847)
);
wwv_flow_imp.component_end;
end;
/
