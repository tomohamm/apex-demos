prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(325948928604455363)
);
wwv_flow_imp.component_end;
end;
/
