prompt --application/deployment/install/install_nyc_highschools_data
begin
--   Manifest
--     INSTALL: INSTALL-NYC Highschools Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14698526397294203)
,p_install_id=>wwv_flow_imp.id(315950512812535378)
,p_name=>'NYC Highschools Data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --HIGH_SCHOOLS: 427/10000 rows exported, APEX$DATA$PKG/HIGH_SCHOOLS$27409',
'    apex_data_install.load_supporting_object_data(p_table_name => ''HIGH_SCHOOLS'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
