prompt --application/deployment/install/install_application_users
begin
--   Manifest
--     INSTALL: INSTALL-Application Users
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8301073269796908)
,p_install_id=>wwv_flow_imp.id(315950512812535378)
,p_name=>'Application Users'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'    l_password  VARCHAR2(10)    :=  ''APEX##123##'';',
'    l_app_id    NUMBER          :=  v(''FB_FLOW_ID'');',
'BEGIN',
'    begin',
'        apex_util.create_user(',
'            p_user_name                     => ''JOHN.DOE'',',
'            p_first_name                    => ''John'',',
'            p_last_name                     => ''Doe'',',
'            p_email_address                 => ''john.doe.ocw@gmail.com'',',
'            p_web_password                  => l_password,',
'            p_change_password_on_first_use  => ''N'',',
'            p_allow_app_building_yn         => ''N'');',
'    exception',
'        when others then ',
'            dbms_output.put_line(''JOHN.DOE exists.'');',
'    end;',
'',
'    begin',
'        apex_util.create_user(',
'            p_user_name                     => ''NYC.ADMIN'',',
'            p_first_name                    => ''School'',',
'            p_last_name                     => ''Administrator'',',
'            p_email_address                 => ''schooladm.ocw@gmail.com'',',
'            p_web_password                  => l_password,',
'            p_change_password_on_first_use  => ''N'',',
'            p_allow_app_building_yn         => ''N'');',
'',
'        APEX_ACL.ADD_USER_ROLE (',
'            p_application_id    => l_app_id,',
'            p_user_name         => ''NYC.ADMIN'',',
'            p_role_static_id    => ''ADMINISTRATOR'' );',
'        ',
'    exception',
'        when others then ',
'            dbms_output.put_line(''NYC.ADMIN exists.'');',
'    end;',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
