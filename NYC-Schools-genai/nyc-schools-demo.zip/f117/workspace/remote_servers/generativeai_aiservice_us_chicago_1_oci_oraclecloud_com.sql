prompt --workspace/remote_servers/generativeai_aiservice_us_chicago_1_oci_oraclecloud_com
begin
--   Manifest
--     REMOTE SERVER: generativeai-aiservice-us-chicago-1-oci-oraclecloud-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>7348844665652076
,p_default_application_id=>117
,p_default_id_offset=>7350033106655718
,p_default_owner=>'WKSP_WKSPNYCDEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(32516650025279416)
,p_name=>'generativeai-aiservice-us-chicago-1-oci-oraclecloud-com'
,p_static_id=>'generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'),'https://generativeai.aiservice.us-chicago-1.oci.oraclecloud.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('generativeai_aiservice_us_chicago_1_oci_oraclecloud_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
