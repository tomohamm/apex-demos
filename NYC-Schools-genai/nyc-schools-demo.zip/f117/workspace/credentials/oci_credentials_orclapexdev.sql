prompt --workspace/credentials/oci_credentials_orclapexdev
begin
--   Manifest
--     CREDENTIAL: OCI Credentials - orclapexdev
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(24514256500069377)
,p_name=>'OCI Credentials - orclapexdev'
,p_static_id=>'OCI_CREDS'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaansast2ca2dhk2jyp7ygazbb2l5nt6f6ocw3qfxzmgufyxmpndo3a'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
