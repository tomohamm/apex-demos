prompt --workspace/credentials/app_109_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 109 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>9997008666912480
,p_default_application_id=>117
,p_default_id_offset=>9998415791919985
,p_default_owner=>'WKSP_NYCDEMO'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(51020314320966551)
,p_name=>'App 109 Push Notifications Credentials'
,p_static_id=>'App_109_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
