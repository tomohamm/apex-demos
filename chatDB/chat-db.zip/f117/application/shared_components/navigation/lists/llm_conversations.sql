prompt --application/shared_components/navigation/lists/llm_conversations
begin
--   Manifest
--     LIST: LLM Conversations
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>59850945956563822
,p_default_application_id=>117
,p_default_id_offset=>59852563374584515
,p_default_owner=>'WKSP_WKSPDEMOAPPTEST'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(191981101605730924)
,p_name=>'LLM Conversations'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1, ',
'    summary,',
'    APEX_PAGE.GET_URL(p_page => 1, p_items => ''P1_CONV_ID'', P_values => id), ',
'    case when :P1_CONV_ID = id then ''Y''else ''N'' end , ',
'    ''fa fa-comment-o'' as image from OCW23_conversations ',
'where ',
'    username = :app_user ',
'        and summary is not null order by STARTED_ON desc;'))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
