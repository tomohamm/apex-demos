prompt --application/shared_components/logic/application_processes/get_response
begin
--   Manifest
--     APPLICATION PROCESS: GET_RESPONSE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>59850945956563822
,p_default_application_id=>117
,p_default_id_offset=>59852563374584515
,p_default_owner=>'WKSP_WKSPDEMOAPPTEST'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(192615994047454447)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_RESPONSE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_response ocw23_prompts.response%type;',
'begin',
'    select response into l_response from ocw23_prompts where id = apex_application.g_x01;',
'   ',
'',
'   apex_json.open_object;',
'   apex_json.write(''id'',apex_application.g_x01 );',
'   apex_json.write(''response'',l_response );',
'   apex_json.close_object;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
