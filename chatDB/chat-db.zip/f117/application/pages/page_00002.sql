prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>59850945956563822
,p_default_application_id=>117
,p_default_id_offset=>59852563374584515
,p_default_owner=>'WKSP_WKSPDEMOAPPTEST'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Explore'
,p_alias=>'REPORT'
,p_step_title=>'Explore'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_navigation_list_position=>'SIDE'
,p_navigation_list_id=>wwv_flow_imp.id(191981101605730924)
,p_navigation_list_template_id=>wwv_flow_imp.id(49943380744523817468)
,p_nav_list_template_options=>'#DEFAULT#:t-TreeNav--styleA:js-navCollapsed--hidden'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'MARTY'
,p_last_upd_yyyymmddhh24miss=>'20230922221349'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(209150901226561561)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49943332036631817448)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(49942816382455817400)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(49943394568331817475)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(241117867162553782)
,p_plug_name=>'REPORT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49943309840082817439)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P2_SQL IS NULL THEN',
'RETURN Q''[select',
'       C001,',
'       C002,',
'       C003,',
'       C004,',
'       C005,',
'       N001,',
'       N002,',
'       N003,',
'       N004,',
'       N005,',
'       D001,',
'       D002,',
'       D003,',
'       D004,',
'       D005',
'  from APEX_COLLECTIONS]'';',
'  ELSE RETURN :P2_SQL;',
'  END IF;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P2_VAR_COL_LABEL_1,P2_VAR_COL_LABEL_2,P2_VAR_COL_LABEL_3,P2_VAR_COL_LABEL_4,P2_VAR_COL_LABEL_5,P2_NUM_COL_LABEL_1,P2_NUM_COL_LABEL_2,P2_NUM_COL_LABEL_3,P2_NUM_COL_LABEL_4,P2_NUM_COL_LABEL_5,P2_DATE_COL_LABEL_1,P2_DATE_COL_LABEL_2,P2_DATE_COL_LABEL_3,'
||'P2_DATE_COL_LABEL_4,P2_DATE_COL_LABEL_5,P2_SQL'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORT'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189919050546322118)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_1.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189919216974322119)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_2.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189919236787322120)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_3.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189919363270322121)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_4.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189919440058322122)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_5.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_5'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189996986515434020)
,p_name=>'N001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N001'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_1.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>550
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997066924434021)
,p_name=>'N002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N002'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_2.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>560
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997221645434022)
,p_name=>'N003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N003'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_3.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>570
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997316888434023)
,p_name=>'N004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N004'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_4.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>580
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997416648434024)
,p_name=>'N005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N005'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_5.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>590
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_5'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997519255434025)
,p_name=>'D001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D001'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_1.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>600
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997587209434026)
,p_name=>'D002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D002'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_2.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>610
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997712914434027)
,p_name=>'D003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D003'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_3.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>620
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997802047434028)
,p_name=>'D004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D004'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_4.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>630
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(189997873135434029)
,p_name=>'D005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D005'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_5.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>640
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_5'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(189918745024322115)
,p_internal_uid=>16663213184896630
,p_is_editable=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(189999450142436764)
,p_interactive_grid_id=>wwv_flow_imp.id(189918745024322115)
,p_static_id=>'167440'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(189999636367436764)
,p_report_id=>wwv_flow_imp.id(189999450142436764)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190001964044436776)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(189919050546322118)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190002905007436779)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(189919216974322119)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190003661642436782)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(189919236787322120)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190004548174436785)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(189919363270322121)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190005520429436788)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(189919440058322122)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190006405280436791)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(189996986515434020)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190007250067436794)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(189997066924434021)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190008143317436796)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(189997221645434022)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190009056925436798)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(189997316888434023)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190009977092436801)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(189997416648434024)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190010844861436804)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(189997519255434025)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190011805899436807)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(189997587209434026)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190012658653436809)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(189997712914434027)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190013602763436812)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(189997802047434028)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(190014467305436823)
,p_view_id=>wwv_flow_imp.id(189999636367436764)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(189997873135434029)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(189750656730117964)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(209150901226561561)
,p_button_name=>'CLOSE_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(49943392235985817474)
,p_button_image_alt=>'Close Report'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-circle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(189721198094095727)
,p_name=>'P2_CURRENT_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190168242634128394)
,p_name=>'P2_SQL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567421453147439)
,p_name=>'P2_NUM_COL_LABEL_1'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567508129147440)
,p_name=>'P2_NUM_COL_LABEL_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567609460147441)
,p_name=>'P2_NUM_COL_LABEL_3'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567708844147442)
,p_name=>'P2_NUM_COL_LABEL_4'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567786770147443)
,p_name=>'P2_NUM_COL_LABEL_5'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222567896615147444)
,p_name=>'P2_DATE_COL_LABEL_1'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222568041615147445)
,p_name=>'P2_DATE_COL_LABEL_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222568102956147446)
,p_name=>'P2_DATE_COL_LABEL_3'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222568186528147447)
,p_name=>'P2_DATE_COL_LABEL_4'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222568358032147448)
,p_name=>'P2_DATE_COL_LABEL_5'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244005455640987495)
,p_name=>'P2_COL_COUNT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244304333857383613)
,p_name=>'P2_VAR_COL_LABEL_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244304445014383614)
,p_name=>'P2_VAR_COL_LABEL_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244304543889383615)
,p_name=>'P2_VAR_COL_LABEL_3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244304666294383616)
,p_name=>'P2_VAR_COL_LABEL_4'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244304687365383617)
,p_name=>'P2_VAR_COL_LABEL_5'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(241117867162553782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(189918645532322114)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Items'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P2_VAR_COL_LABEL_1   := NULL;',
':P2_VAR_COL_LABEL_2   := null;  ',
':P2_VAR_COL_LABEL_3  := null;',
':P2_VAR_COL_LABEL_4  := null;',
':P2_VAR_COL_LABEL_5  := null;',
':P2_NUM_COL_LABEL_1  := null;',
':P2_NUM_COL_LABEL_2  := null;',
':P2_NUM_COL_LABEL_3  := null;',
':P2_NUM_COL_LABEL_4  := null;',
':P2_NUM_COL_LABEL_5  := null;',
':P2_DATE_COL_LABEL_1  := NULL; ',
':P2_DATE_COL_LABEL_2  := NULL; ',
':P2_DATE_COL_LABEL_3  := NULL; ',
':P2_DATE_COL_LABEL_4  := NULL; ',
':P2_DATE_COL_LABEL_5  := NULL;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16663113692896629
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(189767487441117978)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fill Collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sql VARCHAR2(4000);',
'    l_cursor_id INTEGER;',
'    l_desc_tab dbms_sql.desc_tab;',
'    l_col_cnt   INTEGER;',
'    l_char_columns varchar2(4000);',
'    l_date_columns varchar2(4000);',
'    l_num_columns varchar2(4000);',
'    l_char_counter number := 0;',
'    l_num_counter number := 0;',
'    l_date_counter number := 0;',
'begin',
'',
' ',
'',
'',
'  SELECT showsql into l_sql from OCW23_PROMPTS where id = :P2_CURRENT_ID;',
'',
'   APEX_DEBUG.INFO(''INIT l_sql - ''||l_sql || '' id - ''||:P2_CURRENT_ID);',
'   begin',
'      APEX_COLLECTION.DELETE_COLLECTION(',
'            p_collection_name => ''RESPONSE_REPORT_JARVIS'') ;',
'    exception',
'    when others then ',
'        null;',
'    end;',
'',
'  l_cursor_id := DBMS_SQL.OPEN_CURSOR;',
'  dbms_sql.parse(l_cursor_id, l_sql, dbms_sql.native);',
'  dbms_sql.describe_columns(l_cursor_id, l_col_cnt, l_desc_tab);',
'',
'  :P2_COL_COUNT := l_col_cnt;',
'',
'  FOR i IN 1..l_col_cnt LOOP',
'',
'  IF  l_desc_tab(i).col_type = 1 then -- VARCHAR2',
'    l_char_counter := l_char_counter + 1;',
'    if l_char_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_VAR_COL_LABEL_''||l_char_counter, l_desc_tab(i).col_name, true); ',
'',
'    l_char_columns := l_char_columns || '',"''||l_desc_tab(i).col_name||''" AS C00''||l_char_counter;',
'',
'  ELSif l_desc_tab(i).col_type = 2 then -- NUMBER',
'    l_num_counter := l_num_counter + 1;',
'    if l_num_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_NUM_COL_LABEL_''||l_num_counter, l_desc_tab(i).col_name, true); ',
'APEX_DEBUG.INFO(''P2_NUM_COL_LABEL_''||l_num_counter ||''- ''||APEX_UTIL.gET_SESSION_STATE(''P2_NUM_COL_LABEL_''||l_num_counter));',
'    l_num_columns := l_num_columns || '',"''||l_desc_tab(i).col_name ||''" AS N00''||l_num_counter;',
'   ELSif l_desc_tab(i).col_type = 12 then -- DATE',
'    l_date_counter := l_date_counter + 1;',
'     if l_date_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_DATE_COL_LABEL_''||l_date_counter, l_desc_tab(i).col_name, true); ',
'',
'    l_date_columns := l_date_columns || '',"''||l_desc_tab(i).col_name||''" AS D00''||l_date_counter;',
'',
'  END IF;',
'',
'  ',
'',
'  ',
'  end loop;',
'',
'  ',
'',
'  if l_num_counter < 5 then ',
'    for i in l_num_counter +1..5 loop',
'        l_num_columns := l_num_columns ||'',null AS N00''||i;',
'    end loop;',
'  end if;',
'',
' if l_date_counter < 5 then ',
'    for i in l_date_counter+1..5 loop',
'        l_date_columns := l_date_columns ||'',null AS D00''||i;',
'    end loop;',
'  end if;',
'',
'',
'',
'  IF INSTR(l_CHAR_columns, '','') = 1 THEN ',
'    l_CHAR_columns := SUBSTR(l_CHAR_columns, 2);',
'  END IF;',
'',
'  IF INSTR(l_num_columns, '','') = 1 THEN ',
'    l_num_columns := SUBSTR(l_num_columns, 2);',
'  END IF;',
'',
' IF INSTR(l_date_columns, '','') = 1 THEN ',
'    l_date_columns := SUBSTR(l_date_columns, 2);',
'  END IF;',
'',
'',
'  APEX_DEBUG.INFO(''l_date_columns - ''||l_date_columns);',
'  APEX_DEBUG.INFO(''l_num_columns - ''||l_num_columns);',
'  APEX_DEBUG.INFO(''l_CHAR_columns - ''||l_CHAR_columns);',
'',
' ',
'  l_sql := ''SELECT '' || l_num_columns||',
'  (CASE WHEN l_date_columns is not null then '' , ''||l_date_columns',
'    else null end )||(CASE WHEN l_char_columns is not null then '' , ''||l_char_columns',
'    else null end ) ||'' FROM (''||l_sql||'' )'';',
'',
'  APEX_DEBUG.INFO(''l_sql - ''||l_sql);',
'',
'--   APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY2 (',
'--         p_collection_name => ''RESPONSE_REPORT_JARVIS'', ',
'--         p_query => l_sql,',
'--         p_generate_md5 => ''NO'');',
'',
':P2_SQL := l_sql;',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16511955601692493
);
wwv_flow_imp.component_end;
end;
/
