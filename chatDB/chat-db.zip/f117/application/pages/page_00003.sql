prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>59850945956563822
,p_default_application_id=>117
,p_default_id_offset=>59852563374584515
,p_default_owner=>'WKSP_WKSPDEMOAPPTEST'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Explain'
,p_alias=>'EXPLAIN'
,p_step_title=>'Explain'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pre{',
'    white-space: pre-wrap !important;       /* Since CSS 2.1 */',
'    white-space: -moz-pre-wrap !important;  /* Mozilla, since 1999 */',
'    white-space: -pre-wrap !important;      /* Opera 4-6 */',
'    white-space: -o-pre-wrap !important;    /* Opera 7 */',
'    word-wrap: break-word !important;       /* Internet Explorer 5.5+ */',
'    font-family: inherit !important;',
'    font-size: inherit !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_navigation_list_position=>'SIDE'
,p_navigation_list_id=>wwv_flow_imp.id(191981101605730924)
,p_navigation_list_template_id=>wwv_flow_imp.id(49943380744523817468)
,p_nav_list_template_options=>'#DEFAULT#:t-TreeNav--styleA:js-navCollapsed--hidden'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'TOUFIQ'
,p_last_upd_yyyymmddhh24miss=>'20230927141720'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(189447490712284960)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49943332036631817448)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(49942816382455817400)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(49943394568331817475)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(189998222687434032)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(49943319671403817443)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(193030017815624006)
,p_plug_name=>'Explanation'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(49942853008155817416)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_explanation clob;',
'    l_showsql OCW23_PROMPTS.showsql%type;',
'    l_profile_name user_cloud_ai_profiles.profile_name%type := lower(APEX_UTIL.GET_PREFERENCE(       ',
'         p_preference => ''CLOUD_AI_PROFILE'',',
'            p_user       => :APP_USER));',
'begin',
'    SELECT SHOWSQL into l_showsql FROM OCW23_PROMPTS WHERE ID = :P3_CURRENT_ID;',
'',
'    -- ''explain this sql query to a non-technical user:'' ',
'    return ''<h3>Explanation: </h3><div><pre>''||dbms_cloud_ai.generate(',
'            prompt => ''explain this sql query to a non-technical user: ''||l_showsql  ,',
'            action => ''chat'',',
'            profile_name => l_profile_name',
'    )||''</pre></div>'';',
'',
'end;'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P3_CURRENT_ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(189448995802290022)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(189998222687434032)
,p_button_name=>'UPDATE_SQL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(49943392932385817474)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update SQL'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187437691894389734)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(189447490712284960)
,p_button_name=>'CLOSE_SQL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(49943392235985817474)
,p_button_image_alt=>'Close SQL'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-circle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187437523179389732)
,p_name=>'P3_CURRENT_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(189448217696288106)
,p_name=>'P3_SQL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(189998222687434032)
,p_use_cache_before_default=>'NO'
,p_source=>'SELECT SHOWSQL FROM OCW23_PROMPTS WHERE ID = :P3_CURRENT_ID;'
,p_source_type=>'QUERY'
,p_display_as=>'PLUGIN_COM.APEXBYG.BLOGSPOT.CODEMIRROR'
,p_field_template=>wwv_flow_imp.id(49943390404346817473)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(189998398169434034)
,p_validation_name=>'Check Valid SQL'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_cursor NUMBER := dbms_sql.open_cursor;',
'BEGIN',
'            DBMS_SQL.PARSE (l_cursor, :P3_SQL, DBMS_SQL.native);',
'            return null;',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                return sqlerrm;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(189998105834434031)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update SQL'
,p_process_sql_clob=>'update OCW23_PROMPTS set showsql = REPLACE(:P3_SQL,'';'') where id = :P3_CURRENT_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'SQL Updated'
,p_internal_uid=>16742573995008546
);
wwv_flow_imp.component_end;
end;
/
